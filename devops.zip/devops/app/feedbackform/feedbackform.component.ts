import { Component, OnInit } from '@angular/core';
import { FeedbackformService } from './feedbackform.service'
import { Router } from '@angular/router';
import { Key } from 'protractor';
import 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';
import { listener } from '@angular/core/src/render3/instructions';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


declare const jQuery: any;
declare var google: any;
declare var $: any;
declare var toastr: any;


@Component({
  selector: 'app-feedbackform',
  templateUrl: './feedbackform.component.html',
  styleUrls: ['./feedbackform.component.css'],
  providers: [FeedbackformService]

})
export class FeedbackformComponent implements OnInit {
  jsonData: any;
  selectedValue: any;
  angular: any;
  value: any;
  ival1: string;
  feedpage1: boolean;
  feedpage2: boolean;
  feedpage3: boolean;
  questionid: any;
  feedpage4: boolean;
  next: boolean;
  abc: any;
  ival2: any;
  ival3: any;
  dynamic: number;
  type: number;
  qprogressbar: number;
  qcount12: any;
  transactionData: any;
  message: any;
  answers: string;
  constructor(private router: Router, private feedbackformService: FeedbackformService, private _formBuilder: FormBuilder) {
    this.ival1 = sessionStorage.getItem('firstPageData1');
  this.next=true; 

  }
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;



  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": false,
      "progressBar": true,
      "positionClass": "toast-top-right",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "1000",
      "hideDuration": "1000",
      "timeOut": "1000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
 
    

    this.questionid = 1;
    this.getusersListview();
    this.getcountData();
    this.qcount12=0;
    
  }
  
  data = [];
  qdata: any;
  ival: any;
  arrayAnswer=[];
  
//--------------
qcount=[];

// click function ---------------------------------------------------
  click(val) {
    this.ival = val;
    console.log(this.ival)

  }
  // click function end ----------------------------------------------
dataStore:any;
  getusersListview() {
    this.data = [];

    this.feedbackformService.getuserListData().subscribe(response => {
      delete this.dataStore;
      this.dataStore=response;
      let res: any = response;

      if (res[res.length - 1].questions.id == this.questionid) {
        this.next = false;
      }
      for (let i = 0; i < res.length; i++) {
        if (res[i].questions.id == this.questionid){
          this.qdata = res[i].questions.question;
          this.data.push(res[i].answer);
          
        }
      }

     

    }, (err) => {
      console.log(err)
    })
  }
  getcountData(){
    this.feedbackformService.getQcountData().subscribe(response => {
      this.qprogressbar=response;

    }, (err) => {
      console.log(err)
    })
  }

  nextcall(){
    this.data = [];
    let res: any = this.dataStore;

    if (res[res.length - 1].questions.id == this.questionid) {
      this.next = false;
    }
    for (let i = 0; i < res.length; i++) {
      if (res[i].questions.id == this.questionid){
        this.qdata = res[i].questions.question;
        this.data.push(res[i].answer);
        
      }
    }

  }

qcountper:any;
//save next funation---------------------
  saveData() {
    console.log(this.ival);
    console.log(this.arrayAnswer);
    if ($("input[name='radio1']").is(':checked')){
   if (this.ival != undefined) {
    this.feedpage1 = true;

    if(this.arrayAnswer[this.questionid-1]==undefined){ 
      this.arrayAnswer.push(this.ival);
     
    console.log(this.arrayAnswer);
    }else{
      
        this.arrayAnswer[this.questionid-1]=this.ival;
      
      
    }
    this.questionid = this.questionid + 1;
if(this.arrayAnswer[this.questionid-1]!=undefined){
  this.abc=this.arrayAnswer[this.questionid-1];
  this.ival = this.abc;
}

let dcountvalue :any=(100* this.questionid)/this.qprogressbar;
this.qcount12=parseInt(dcountvalue);
console.log(this.qcount12.to);
    this.nextcall();  
   }else{
    toastr.error('Please make a selection');
   }}else{
     toastr.error('Please make a selection');

    }
  }

  //save next end funation----------------


  //previous btn start-----------------
  PrevioussaveData(){
    this.next = true;
    this.questionid = this.questionid - 1;


let dcountvalue :any=(100* this.questionid)/this.qprogressbar;
this.qcount12=parseInt(dcountvalue);
    //this.arrayAnswer.push(this.ival);

    this.getusersListview1();
  }

  // previous button function -------------

  getusersListview1() {
    this.data = [];
  
  //  this.feedbackformService.getuserListData().subscribe(response => {
      let res: any = this.dataStore;
      if(res[res.length-1].questions.id==this.questionid){
      this.next=false;
      }
      for (let i = 0; i < res.length; i++) {

        const arr1 = [];
        if (res[i].questions.id == this.questionid) {
          this.qdata = res[i].questions.question;
          this.data.push(res[i].answer);
        }
        if(res[i] == res[res.length -1]){
        for(let j = 0;j < this.data.length;j++){
          console.log(this.data[j] , this.arrayAnswer[this.arrayAnswer.length -1])
          if(this.data[j] == this.arrayAnswer[this.questionid -1]){
            this.abc = this.data[j];
            if(this.arrayAnswer[this.questionid -1]  == this.data[j]){
              if(this.arrayAnswer.length == 1){
                this.ival = this.abc;
               //this.arrayAnswer.pop();
                console.log("length of array " + this.ival)
              }else {
                this.ival = this.abc;

              //let removedelement=this.arrayAnswer.pop();
             // this.arrayAnswer.push(removedelement);
              }
              console.log(this.arrayAnswer)
            }
            return;
          }
        }
      }
      }
    // }, (err) => {
    //   console.log(err)
    // })
  }

    //previous btn start end-----------------

    getusersListviewLoad(){
    console.log('answers----->', this.data);
        
              }
    
sendArray=[];
    saveDatafinish(){
    
      if(this.arrayAnswer[this.questionid-1]==undefined){ 
        this.arrayAnswer.push(this.ival);
       
      console.log(this.arrayAnswer);
      }else{
        this.arrayAnswer[this.questionid-1]=this.ival;

      }
      const names = this.arrayAnswer;
      if ($("input[name='radio1']").is(':checked')){

    let x = (names) => names.filter((v,i) => names.indexOf(v) === i) 
     x(names);
      console.log(x(names));
      for(let j=0;j<this.arrayAnswer.length;j++){

        this.sendArray.push(this.arrayAnswer[j] + "~#~");
      }
      console.log(this.sendArray);

      this.router.navigate(['/feedbackform4']); 
      setTimeout(() => {
        this.router.navigate([''] )   
      }, 6000); 
      
      this.postDataofArray();
    }else{
      toastr.error('Please make a selection');
 
     }
    // }else{
    //   toastr.error('Please make a selection');
  
    //  }
      
    }
    postDataofArray(){
   
    sessionStorage.getItem("username");
     this.jsonData={};
 this.jsonData.name =  sessionStorage.getItem("username");
 this.jsonData.answers=this.sendArray.toString();


 this.feedbackformService.saveAnswers(this.jsonData)
 .subscribe(response => {
   console.log(response);
  let res:any = response;
   this.transactionData = JSON.parse(res._body);
   this.message = this.transactionData.message;
            
  
  this.resetFormHome();
            }, error => {
  
          toastr.error('Failed to save Data!', 'failed!');

 });
 
 
 }

 resetFormHome(){
  this.answers = '' ;
  sessionStorage.removeItem("username");
 
  
}
    


  firstClick(_value) {
    console.log(_value);
    sessionStorage.setItem("selectedvalue1", _value);
  }
  nextFun(id1) {
    console.log(id1);
  }
  counter = 0;
  max = 30;
  increment(){
this.counter =this.counter + 1;
    this.dynamic = this.counter / this.max * 100;
     this.type =this.counter % 4;
  }
    


}

