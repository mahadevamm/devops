import { TestBed, inject } from '@angular/core/testing';

import { FeedbackformService } from './feedbackform.service';

describe('FeedbackformService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FeedbackformService]
    });
  });

  it('should be created', inject([FeedbackformService], (service: FeedbackformService) => {
    expect(service).toBeTruthy();
  }));
});
