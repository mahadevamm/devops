import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
@Injectable({
  providedIn: 'root'
})
export class Feedbackpage3Service {


  public userListUrl ;
  constructor(public http :Http) { }
  getuserListData() {
    // let body = JSON.stringify(user);
    let url: string = environment.searchApi;
    return this.http.get(url + '/questionAnswer/questionAnswerList')
        .map(res => res.json())
        .map((res) => {
          //console.log('service res', res);
            return res;
        })
}
}
