import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Feedbackpage3Component } from './feedbackpage3.component';

describe('Feedbackpage3Component', () => {
  let component: Feedbackpage3Component;
  let fixture: ComponentFixture<Feedbackpage3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Feedbackpage3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Feedbackpage3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
