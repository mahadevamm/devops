import { TestBed, inject } from '@angular/core/testing';

import { Feedbackpage3Service } from './feedbackpage3.service';

describe('Feedbackpage3Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Feedbackpage3Service]
    });
  });

  it('should be created', inject([Feedbackpage3Service], (service: Feedbackpage3Service) => {
    expect(service).toBeTruthy();
  }));
});
