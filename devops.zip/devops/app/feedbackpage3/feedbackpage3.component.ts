import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';
import {Feedbackpage3Service} from  './feedbackpage3.service';

declare const jQuery: any;
declare var google: any;
declare var $: any;
declare var toastr: any;
@Component({
  selector: 'app-feedbackpage3',
  templateUrl: './feedbackpage3.component.html',
  styleUrls: ['./feedbackpage3.component.css']
})
export class Feedbackpage3Component implements OnInit {

  constructor(private router: Router,private feedbackpage3Service : Feedbackpage3Service) { }

  ngOnInit() {
  }
  PrevioussaveData3(){
    this.router.navigate(['/feedbackform2']);
  }
  firstClick3(value){
    
    sessionStorage.setItem("selectedvalue3",value);
  }
  saveData3(){
    this.router.navigate(['/feedbackform4']);

  }

  //component

PrevioussaveData2(){
  this.router.navigate(['/feedbackform']);
}
firstClick2(value){

  // sessionStorage.setItem("selectedvalue2",value);
}









data2 = [];
qdata2: any;
ival2: any;
click2(val) {
  this.ival2 = val;
 
} 
getusersListview(){
  this.feedbackpage3Service.getuserListData().subscribe(response => {
    let res:any = response;
      console.log(res)

      for (var key in res) {
        if (res.hasOwnProperty(key)) {
            console.log('key', key);
            console.log('value', res[key]);
            console.log(res[key]=="what is DevOps?");
        }
    }
for(let i=0; i<res.length;i++){
const arr1 = [];
console.log(res[i].answer);
console.log(res[i].questions.id);
if(res[i].questions.id == 2) {
  this.qdata2 = res[i].questions.question;
  this.data2.push(res[i].answer);
}
console.log('answers2----->', this.data2);

}
},(err)=>{
      console.log(err)
    })
  }
  saveData2(){
    sessionStorage.setItem("firstPageData2",this.ival2);
    if ($("input[name='radio1']").is(':checked')) {
      this.router.navigate(['/feedbackform3']);   
    
    }else{
    toastr.error('Nothing is checked!');

   }
    

  }
  firstClick(_value){
    console.log(_value);
    sessionStorage.setItem("selectedvalue1",_value);
  }
nextFun(id1){
console.log(id1);
}

saveDataFineshed(){

}



}
