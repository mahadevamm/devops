import { Routes, RouterModule } from '@angular/router';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { FeedbackformComponent } from './feedbackform/feedbackform.component';
import {Feedbackpage2Component} from './feedbackpage2/feedbackpage2.component';
import {Feedbackpage3Component} from './feedbackpage3/feedbackpage3.component';
import { Feedbackpage4Component } from './feedbackpage4/feedbackpage4.component';

export const routes: Routes = [
  { path: '',component: WelcomepageComponent },
{path:'feedbackform',component: FeedbackformComponent },
{path:'feedbackform2' ,component:Feedbackpage2Component},
{path:'feedbackform3' ,component:Feedbackpage3Component},
{path:'feedbackform4' ,component:Feedbackpage4Component}


];

export const routing = RouterModule.forRoot(routes);