import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Feedbackpage4Component } from './feedbackpage4.component';

describe('Feedbackpage4Component', () => {
  let component: Feedbackpage4Component;
  let fixture: ComponentFixture<Feedbackpage4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Feedbackpage4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Feedbackpage4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
