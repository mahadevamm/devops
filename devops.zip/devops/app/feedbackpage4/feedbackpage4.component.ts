import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feedbackpage4',
  templateUrl: './feedbackpage4.component.html',
  styleUrls: ['./feedbackpage4.component.css']
})
export class Feedbackpage4Component implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

}
