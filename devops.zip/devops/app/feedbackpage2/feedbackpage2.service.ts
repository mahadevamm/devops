import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
import { map } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class Feedbackpage2Service {
  public userListUrl ;
  constructor(public http :Http) { }
	
	// getuserListData(){
  //   let url: string = environment.searchApi;
	//  let userListUrl = '/questionAnswer/questionAnswerList';
  //   return this.http.get(url+userListUrl).map(userlist => {
  //     return  userlist;
	// 	//console.log("usersData = "+userlist)
  //   }, err => {
	// console.log("err");
	// });
  // }

  getuserListData() {
    // let body = JSON.stringify(user);
    let url: string = environment.searchApi;
    return this.http.get(url + '/questionAnswer/questionAnswerList')
        .map(res => res.json())
        .map((res) => {
          console.log('service res', res);
            return res;
        })
}
}

