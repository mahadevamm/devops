import { TestBed, inject } from '@angular/core/testing';

import { Feedbackpage2Service } from './feedbackpage2.service';

describe('Feedbackpage2Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Feedbackpage2Service]
    });
  });

  it('should be created', inject([Feedbackpage2Service], (service: Feedbackpage2Service) => {
    expect(service).toBeTruthy();
  }));
});
