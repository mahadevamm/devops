import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Feedbackpage2Component } from './feedbackpage2.component';

describe('Feedbackpage2Component', () => {
  let component: Feedbackpage2Component;
  let fixture: ComponentFixture<Feedbackpage2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Feedbackpage2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Feedbackpage2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
