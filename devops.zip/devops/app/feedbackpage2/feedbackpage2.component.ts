import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Feedbackpage2Service} from  './feedbackpage2.service';

import { Key } from 'protractor';
import 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

declare const jQuery: any;
declare var google: any;
declare var $: any;
declare var toastr: any;

@Component({
  selector: 'app-feedbackpage2',
  templateUrl: './feedbackpage2.component.html',
  styleUrls: ['./feedbackpage2.component.css'],
  providers : [Feedbackpage2Service]

})

export class Feedbackpage2Component implements OnInit {

  constructor(private router: Router,private feedbackpage2Service : Feedbackpage2Service,private _formBuilder: FormBuilder) { }
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });

    this.getusersListview();
    

  }
  
  PrevioussaveData2(){
    this.router.navigate(['/feedbackform']);
  }
  firstClick2(value){

    // sessionStorage.setItem("selectedvalue2",value);
  }
  








data2 = [];
  qdata2: any;
  ival2: any;
  click2(val) {
    this.ival2 = val;
   
  } 
  getusersListview(){
    this.feedbackpage2Service.getuserListData().subscribe(response => {
      let res:any = response;
        console.log(res)

      //   for (var key in res) {
      //     if (res.hasOwnProperty(key)) {
      //         console.log('key', key);
      //         console.log('value', res[key]);
      //         console.log(res[key]=="what is DevOps?");
      //     }
      // }
for(let i=0; i<res.length;i++){
  const arr1 = [];
  console.log(res[i].answer);
  console.log(res[i].questions.id);
  if(res[i].questions.id == 2) {
    this.qdata2 = res[i].questions.question;
    this.data2.push(res[i].answer);
  }
  console.log('answers2----->', this.data2);

}
},(err)=>{
        console.log(err)
      })
    }
    saveData2(){
      sessionStorage.setItem("firstPageData2",this.ival2);
      if ($("input[name='radio1']").is(':checked')) {
        this.router.navigate(['/feedbackform3']);   
      
      }else{
      toastr.error('Nothing is checked!');

     }
      

    }


    
    firstClick(_value){
      console.log(_value);
      sessionStorage.setItem("selectedvalue1",_value);
    }
nextFun(id1){
  console.log(id1);
}

saveDataFineshed(){

}
}
