import { TestBed, inject } from '@angular/core/testing';

import { WelcomepageService } from './welcomepage.service';

describe('WelcomepageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WelcomepageService]
    });
  });

  it('should be created', inject([WelcomepageService], (service: WelcomepageService) => {
    expect(service).toBeTruthy();
  }));
});
