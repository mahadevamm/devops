import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class WelcomepageService {

  constructor(public http :Http) { }
  
  public saveUser(jsonArray: any) {
	   let url: string = environment.searchApi;
     url += '/saveuser/save';
   console.log('** insert clli-zone-lookup jsonData: ' + jsonArray);
   console.log('url'+ this.http.post(url, jsonArray));
   return this.http.post(url, jsonArray);
   

 }
}
