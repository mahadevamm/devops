import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {WelcomepageService} from './welcomepage.service'
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { AfterViewInit, ElementRef } from '@angular/core';

declare var toastr: any;

@Component({
  selector: 'app-root',
  templateUrl: './welcomepage.component.html',
  styleUrls: ['./welcomepage.component.css'],
  providers:[WelcomepageService]
})
export class WelcomepageComponent implements OnInit {
  uname :any ;
  uemail: any;
  pnumber: any;
  udepname: any;
jsonData:any = {};
transactionData :any;
message = "";
ccountry: any;
ccompanyname:any;
ccompanysize:any;
  constructor(private router: Router,private welcomepageservice : WelcomepageService,private el: ElementRef) { }

  ngOnInit() {
    toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": false,
      "progressBar": true,
      "positionClass": "toast-top-right",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": "1000",
      "hideDuration": "1000",
      "timeOut": "1000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
    // const inputList = [].slice.call((<HTMLElement>this.el.nativeElement).getElementsByTagName('full_name'));
    // inputList.forEach((input: HTMLElement) => {
    //     input.addEventListener('focus', () => {
    //         let inputClass = input.className;
    //         input.classList.toggle('active');
    //     });
    //     input.addEventListener('blur', () => {
    //         input.classList.toggle('active');
    //     });
    // });

  }

  public shouldShow = false;
  public shouldShow2 = false;
  public shouldShow3 = false;
  public shouldShow4 = false;
  public shouldShow5 = false;
  public shouldShow6 = false;


  
  // private toogleClass(input : HTMLElement){
  //   let inputClass = input.classList.toggle('active');


  // }
  validateEmail(email){
   
  }
  redirectpageHome(){

	this.loaduserformData();
  var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  var isphone222 =/^\d{12}$/;
 
  	if(this.uname == "" || this.uname == undefined){
		toastr.error('Please Enter your Name');
		return false;
	}else if(!isphone222.test(this.pnumber)){
    toastr.error('Please Enter your number');
      return false;
    }else if(!re.test(this.uemail)) {
    
      toastr.error( "Please enter valid emailID.")
       return false;
     }
  else if( this.ccompanyname == "" ||  this.ccompanyname== undefined){
    toastr.error('Please Enter company name');
  return false;
}else if(this.ccountry == "" || this.ccountry== undefined){
			toastr.error('Please Enter country name');
		return false;
  }else if( this.ccompanysize== "" ||  this.ccompanysize== undefined){
  toastr.error('Please Enter company size');
return false;
}
  
  
  
 
	
 	 this.welcomepageservice.saveUser(this.jsonData)
    .subscribe(response => {
      console.log(response);
		 let res:any = response;
      this.transactionData = JSON.parse(res._body);
      this.message = this.transactionData.message;
               
      this.router.navigate(['/feedbackform']);
     
     this.resetForm();
               }, error => {
     
		         toastr.error('Failed to save Data!', 'failed!');

    });

  
  }
  
  
  
  loaduserformData(){
   sessionStorage.setItem("username",this.uname);
		this.jsonData={};
this.jsonData.name = this.uname;
this.jsonData.emailId=this.uemail;
this.jsonData.phoneNumber=this.pnumber;
this.jsonData.countryName=this.ccountry;
this.jsonData.companyName=this.ccompanyname;
this.jsonData.companySize=this.ccompanysize;


} 
  
	
  loadLoginPage(){
  	this.router.navigate(['/feedbackform']);
  }
  
  resetForm(){
		this.uname = '' ;
		this.uemail = '' ;
		this.pnumber = '' ;
this.ccountry='';
this.ccompanyname='';
this.ccompanysize='';
		
	}
  
  // focusFunction(){
  //   let element = document.getElementById('datetimepicker12');
  //   element.className = 'example-class';

  // }(focus)="focusFunction()" (focusout)="focusout()"
  // focusout(){

  // }
  myfunction(value){
    let v=value;
    if(v==1){

    }else{
      
    }
  }
  
  
  
}

