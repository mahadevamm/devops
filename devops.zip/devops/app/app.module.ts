import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { routing } from './app.routes';
import { WelcomepageComponent } from './welcomepage/welcomepage.component';
import { FeedbackformComponent } from './feedbackform/feedbackform.component';
import { ToastrModule } from 'ngx-toastr';
import { HttpModule } from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Feedbackpage2Component } from './feedbackpage2/feedbackpage2.component';
import { Feedbackpage3Component } from './feedbackpage3/feedbackpage3.component';
import { Feedbackpage4Component } from './feedbackpage4/feedbackpage4.component';
import {ProgressBarModule} from "angular-progress-bar";
import {MatStepperModule} from '@angular/material/stepper'; 
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material';


@NgModule({
  declarations: [
    AppComponent,
    WelcomepageComponent,
    FeedbackformComponent,
    Feedbackpage2Component,
    Feedbackpage3Component,
    Feedbackpage4Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    routing,
    HttpModule,
    HttpClientModule,
    ProgressBarModule,
    MatStepperModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
        ToastrModule.forRoot({
      timeOut: 1000,
          positionClass: 'toast-top-right',
          preventDuplicates: true,
          closeButton: true
      }),
      BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
